import logo from './logo.svg';
import './App.css';
import Loadingscreen from './Loadingscreen';
 
function App() {
  return (
    <div className='bgcol'>
      <div className='text'>
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>
    </div>
    <p>LOADING</p>
    <p>SCREEN</p>
    <p>REACT</p>
    </div>
    <Loadingscreen/>
    </div>
  );
}
 
export default App;