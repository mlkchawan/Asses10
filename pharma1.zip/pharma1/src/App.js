import './App.css';
import Pharma from './Pharma';
 
function App() {
  return (
    <div>
      <Pharma/>
    </div>
  );
}
 
export default App;